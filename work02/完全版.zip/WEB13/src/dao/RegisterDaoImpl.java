package dao;


import pojo.Users;
import DBUtils.DBUtils;
import dao.RegisterDao;

public class RegisterDaoImpl implements RegisterDao {
	public void register(Users user){
		
			DBUtils.openConnection();
			String sql = "insert users values(?,?,?,?,?,?,?,?,?,?,?)";
			DBUtils.executeUpdate(sql, user.getUsersName(),user.getUsersPwd(),user.getUsersRealname(),user.getUsersSex(),user.getUsersage(),
					user.getUsersCard(),user.getUsersAddress(),user.getUsersPhone(),user.getUsersEmail(),user.getUserscode(),user.getType());
	}
}
