package dao;

import DBUtils.DBUtils;
import pojo.Admin;

public class AdminDaoImpl implements AdminDao {

	
	public void updateAdmin(Admin admin) {
		DBUtils.openConnection();
		String sql = "update  admin set  name =? , pwd=?  where id = ?" ;
		DBUtils.executeUpdate(sql,admin.getAdminName(),admin.getAdminPwd(),admin.getAdminId());
		DBUtils.closeConnection();
		
	}

}
