package dao;

import java.util.List;

import pojo.Menus;
import pojo.Types;

public interface TypeDao {
	public List<Types> getTypes();
	public void addTypes(String typesName);
	public void deleteType(int typesId);
	public void updateType(Types types);
}
