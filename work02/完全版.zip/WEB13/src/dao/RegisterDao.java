package dao;


import pojo.Users;

public interface RegisterDao {
	public void register(Users user);
}
