package dao;

public interface UsersDao {
	public void Deleteuser(int id);
}
