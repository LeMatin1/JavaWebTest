package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtils.DBUtils;
import dao.OrdersDao;
import pojo.Menus;
import pojo.Orders;
import pojo.Users;


public class OrdersDaoImp implements OrdersDao{

	@Override
	/**
	 * �����ܱ��� ��ҳ�����
	 */
	public int ordersCount() {
		
		DBUtils.openConnection();
		String sql = "select count(*) from orders";
		ResultSet res = DBUtils.executeQuery(sql);
		int count = 0;
		
		try {
			if (res.next()) {
				count = res.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeConnection();
		}
		
		return count;
		
	}

	@Override
	public List<Orders> ordersList(int begin,int end) {
		List<Orders> list = new ArrayList<Orders>();
		String sql = "select * from ("+
				"select ROW_NUMBER() over(order by id) rn ,fullInfo.* from "
			+	" (select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
			+	"		(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO,"  //�û������������Ӳ�ѯ ע��ĩβΪO ��������         
			+	"		(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO " //��Ʒ�����������Ӳ�ѯ
			+	"		where menuO.id = userO.orderId ) fullInfo) t "   //��userO menuO ��������
			+ " where t.rn between ? and ?";  // ��ҳ����
			//�������Ӳ�ѯ 
		DBUtils.openConnection();
		ResultSet rs = DBUtils.executeQuery(sql, begin,end);
		
		try {
			while(rs.next()){
				int i =1;   //Ϊ1��ʼ ��ȡ��һ���е��б��
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				System.out.println(i+"daoImp");
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}

	/**
	 * �ͻ�ID�Ҽ�¼
	 */
	@Override
	public List<Orders> ordersselectUsersId(int id) {
		
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and userO.id = ?";
		
		ResultSet rs = DBUtils.executeQuery(sql, id);
		
		try {
			while(rs.next()){
				int i =0;   
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}


	/**
	 * �����Ҽ�¼
	 */
	@Override
	public List<Orders> ordersselectMenusName(String name) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and menuO.name = ?";
		
		ResultSet rs = DBUtils.executeQuery(sql, name);
		
		try {
			while(rs.next()){
				int i =0;   
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}


	/**
	 * ʱ���Ҽ�¼
	 */
	@Override
	public List<Orders> ordersselectOrdersTimes(String time) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and menuO.times= ?";
		
		ResultSet rs = DBUtils.executeQuery(sql,time);
		
		try {
			while(rs.next()){
				int i =0;   //Ϊ1��ʼ ��ȡ��һ���е��б��
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}

	
	@Override
	public void ordersAdd(Orders orders) {
		DBUtils.openConnection();
		String sql = "insert orders values(?,?,?,CONVERT(varchar,GETDATE(),23),1)";
		DBUtils.executeUpdate(sql,orders.getordersUsers().getUsersId(),orders.getordersmenus().getMenusId(),orders.getordersMenusum());
		DBUtils.closeConnection();
		
	}

	@Override
	public void ordersDelete(int id) {
		DBUtils.openConnection();
		String sql = "delete from orders where id = ?";
		DBUtils.executeUpdate(sql, id);
		DBUtils.closeConnection();
	}

	/**
	 * ����ȷ�϶������ͳ�
	 */
	@Override
	public void ordersConfirm(Orders orders) {
		DBUtils.openConnection();
		String sql = "update orders set delivery=2 where id = ?";
		DBUtils.executeUpdate(sql, orders.getordersId());
		DBUtils.closeConnection();
		
	}

	@Override
	public List<Orders> ordersDaySum(String time) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		String sql = "select name,sum(orders.menusum),price from menus,orders "
				+ " where menus.id = orders.menuid  and times = ? group by name,price";
		
		ResultSet rs = DBUtils.executeQuery(sql, time);
		
		try {
			while(rs.next()){
				int i = 0;
				Orders orders = new Orders();
				Menus menus = new Menus();
				menus.setMenusName(rs.getString(++i)); //����
				orders.setordersMenusum(rs.getInt(++i)); //����
				menus.setMenusPrice(rs.getFloat(++i)); //�۸�
				orders.setordersmenus(menus);//����Ʒ��Ϣ����
				list.add(orders);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeConnection();
		}
		
		return list;
	}

	@Override
	public List<Orders> orderHomePage() {
		String sql = "select top 6 name,sum(orders.menusum) from menus "
				+ "left join orders on menus.id = orders.menuid  group by name,price order by sum(orders.menusum) desc";
		List<Orders> list = new ArrayList<Orders>();
		
		DBUtils.openConnection();
		ResultSet rs = DBUtils.executeQuery(sql);
		
		try {
			while(rs.next()){
				Orders orders = new Orders();
				Menus mune = new Menus();
				mune.setMenusName(rs.getString(1));
				orders.setordersmenus(mune);
				orders.setordersMenusum(rs.getInt(2));
				list.add(orders);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeConnection();
		}
		
		DBUtils.closeConnection();
		
		return list;
	}

	@Override
	/**
	 * ǰ�˲����Ҽ�¼
	 */
	public List<Orders> ordersselectMenusName(String name, int id) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and menuO.name = ? and userO.id = ?";
		
		ResultSet rs = DBUtils.executeQuery(sql, name,id);
		
		try {
			while(rs.next()){
				int i =0;   
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}

	/**
	 * ǰ��ʱ���Ҽ�¼
	 */
	@Override
	public List<Orders> ordersselectOrdersTimes(String time, int id) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and menuO.times= ? and userO.id = ?";
		
		ResultSet rs = DBUtils.executeQuery(sql,time,id);
		
		try {
			while(rs.next()){
				int i =0;   //Ϊ1��ʼ ��ȡ��һ���е��б��
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();
				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));
				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}

	public List<Orders> ordersselectOrdersDelivery(int delivery,int id) {
		DBUtils.openConnection();
		List<Orders> list = new ArrayList<Orders>();
		
		String sql = "select userO.id,realname,phone,address,menuO.name,menuO.menusum, menuO.price,times,delivery from "
					+"	(select users.id,realname,phone,address,orders.id as orderId from users,orders where users.id = orders.userid)		userO, "
					+"	(select menus.name,orders.id ,menusum ,price,orders.times,delivery from menus,orders where menus.id = orders.menuid) menuO "
					+"	where menuO.id = userO.orderId and menuO.delivery= ? and userO.id = ?";
		
		ResultSet rs = DBUtils.executeQuery(sql,delivery,id);
		
		try {
			while(rs.next()){
				int i =0;   //Ϊ1��ʼ ��ȡ��һ���е��б��
				System.out.println(i);
				Orders ord = new Orders();
				Users us = new Users();
				Menus me = new Menus();				
				us.setUsersId(rs.getInt(++i));
				us.setUsersRealname(rs.getString(++i));
				us.setUsersPhone(rs.getString(++i));
				us.setUsersAddress(rs.getString(++i));
				ord.setordersUsers(us);				//���û���Ϣ����
				me.setMenusName(rs.getString(++i));  //���ò�Ʒ����
				ord.setordersMenusum(rs.getInt(++i));
				me.setMenusPrice(rs.getFloat(++i));
				ord.setordersmenus(me); //��Ʒ��Ϣ����
				ord.setordersTimes(rs.getString(++i));//i=9
				ord.setordersDelivery(rs.getInt(++i));				
				list.add(ord);
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.openConnection();			
		}
		
		return list;
	}
	
}
