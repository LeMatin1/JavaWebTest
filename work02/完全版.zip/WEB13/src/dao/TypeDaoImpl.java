package dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtils.DBUtils;
import dao.MenusDao;
import dao.TypeDao;
import pojo.Menus;
import pojo.Types;


public class TypeDaoImpl implements TypeDao {

	
	public List<Types> getTypes() {
		DBUtils.openConnection();
		List<Types> tList = new ArrayList();
		String sql = "select * from types";
		ResultSet rs = DBUtils.executeQuery(sql);
		try{
			while(rs.next()){
				Types type = new Types(rs.getInt(1),rs.getString(2));
				tList.add(type);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.closeConnection();
		}
		return tList;
	}

	
	public void addTypes(String typesName) {
		DBUtils.openConnection();
		String sql = "insert types values(?)";
		DBUtils.executeUpdate(sql,typesName);
		
	}


	@Override
	public void deleteType(int typesId) {
		DBUtils.openConnection();
		String sql = "delete from types where id = ?";
		DBUtils.executeUpdate(sql,typesId);
		
		
	}


	@Override
	public void updateType(Types types) {
		DBUtils.openConnection();
		String sql = "update  types set name =? where id = ?" ;
		DBUtils.executeUpdate(sql,types.getTypesName(),types.getTypesId());
		DBUtils.closeConnection();
		
	}

	
}
