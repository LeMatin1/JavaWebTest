package dao;

import pojo.Admin;

public interface AdminDao {
	public void updateAdmin(Admin admin);
}
