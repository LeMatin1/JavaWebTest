package dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtils.DBUtils;
import dao.MenusDao;
import pojo.Menus;
import pojo.Types;


public class MenusDaoImpl implements  MenusDao{

	
	public void addMenu(Menus menus) {
		DBUtils.openConnection();
		String sql = "insert menus values(?,?,?,?,?,?,?,?,?)";
		DBUtils.executeUpdate(sql,menus.getMenusName(),menus.getMenusTypes().getTypesId(),menus.getMenusBurden(),
				menus.getMenusBrief(),menus.getMenusPrice(),0,menus.getMenusPrice1(),0
				,menus.getImgpath());
	}

	
	public List<Menus> getMenusList( ) {
		DBUtils.openConnection();
		List<Menus> mList = new ArrayList();
		String sql = " select * from menus ,types where menus.typeid=types.id ";
		ResultSet rs = DBUtils.executeQuery(sql);
		try{
			while(rs.next()){
				Menus menu = new Menus(rs.getInt(1),rs.getString(2),new Types(rs.getInt(3),rs.getString(12)),rs.getString(4),rs.getString(5)
						,rs.getFloat(6),rs.getInt(7),rs.getFloat(8),rs.getInt(9),rs.getString(10));
				mList.add(menu);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.closeConnection();
		}
		
		return mList;
	}
	public List<Menus> getMenusPageList( int currentPage, int pageSize) {
		DBUtils.openConnection();
		List<Menus> mList = new ArrayList();
		String sql = "  select * from (select * , ROW_NUMBER() over (order by menusInfo.id)  "
				+ " as rn from (select menus.*,types.name as typeName from menus, "
				+ " types where menus.typeid = types.id) menusInfo )t  where rn between ? and ? ";
		ResultSet rs = DBUtils.executeQuery(sql,(currentPage-1)*pageSize+1,currentPage*pageSize);
		try{
			while(rs.next()){
				Menus menu = new Menus(rs.getInt(1),rs.getString(2),new Types(rs.getInt(3),rs.getString(11)),rs.getString(4),rs.getString(5)
						,rs.getFloat(6),rs.getInt(7),rs.getFloat(8),rs.getInt(9),rs.getString(10));
				mList.add(menu);
				System.out.println(menu);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.closeConnection();
		}
		
		return mList;
	}


	
	public void deleteMenu(int menusId) {
		DBUtils.openConnection();
		String sql = "delete from menus where id = ?";
		DBUtils.executeUpdate(sql,menusId);
		
	}


	
	public void updateMenu(Menus menus) {
		DBUtils.openConnection();
		String sql = "update  menus set name = ?, typeid=?, burden=? ,brief = ?,price = ?,  "
				+ "  price1=?  where id = ?" ;
		DBUtils.executeUpdate(sql,menus.getMenusName(),menus.getMenusTypes().getTypesId(),menus.getMenusBurden(),
				 menus.getMenusBrief(),menus.getMenusPrice(),menus.getMenusPrice1(),menus.getMenusId());
		
	}


	
	public int getMenusCount() {
		List<Menus> mList = new ArrayList();
		DBUtils.openConnection();
		String sql = " select count(*) from menus  " ;
		ResultSet rs = DBUtils.executeQuery(sql);
		int count = 0;
		try{
			if(rs.next()){
				count=rs.getInt(1);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.closeConnection();
		}
		return count;
	}


	@Override
	public Menus getMenus(int id) {
		DBUtils.openConnection();
		String sql = "select * from menus where id = ?";
		Menus menus = new Menus();
		
		ResultSet rs = DBUtils.executeQuery(sql, id);
		
		try {
			if (rs.next()) {
				int i = 0;
				menus.setMenusId(rs.getInt(++i));
				menus.setMenusName(rs.getString(++i));
				menus.setMenusPrice1(rs.getFloat(8));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeConnection();
		}
		
		return menus;

	}


	@Override
	public Menus getMenus1(int id) {
		DBUtils.openConnection();
		String sql = "select * from menus where id = ?";
		
		Menus menus = null;
		ResultSet rs = DBUtils.executeQuery(sql, id);
		
		try {
			if (rs.next()) {
				  menus = new Menus(rs.getInt(1), rs.getString(2),rs.getString(4),rs.getFloat(6),rs.getFloat(8),rs.getString(5),rs.getString(10));
				menus.setMenusName(rs.getString(2));
				menus.setMenusBurden(rs.getString(4));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtils.closeConnection();
		}
		
		return menus;
	}
	






}
