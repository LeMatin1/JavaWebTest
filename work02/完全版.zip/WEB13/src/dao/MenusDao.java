package dao;

import java.util.List;

import pojo.Menus;
import pojo.Types;

public interface MenusDao {
	public void addMenu(Menus menus);
	public List<Menus> getMenusPageList(int currentPage, int pageSize);
	public void deleteMenu(int menusId);
	public void updateMenu(Menus menus);
	public int getMenusCount();
	public List<Menus> getMenusList();
	public Menus getMenus(int id);     //ͨ����ƷId ��ȡ��Ʒ��Ϣ
	public Menus getMenus1(int id);
}
