package dao;

import DBUtils.DBUtils;
import dao.UsersDao;


public class UsersDaoImp implements UsersDao{

	@Override
	public void Deleteuser(int id) {
		// TODO Auto-generated method stub
		try{
            DBUtils.openConnection();
            String sql = "delete  from users where id = ?";
            DBUtils.executeUpdate(sql, id);

        }finally{
            DBUtils.closeConnection();
        }
		
	}

}
