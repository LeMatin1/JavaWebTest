package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtils.DBUtils;
import pojo.Admin;
import pojo.Notice;




public class dfaceClass implements dface{
       DBUtils d = new DBUtils();
	@Override
	public Admin login(Admin u) {
		d.openConnection();
		String sql = "select * from admin where name = ? and pwd = ?";
		ResultSet rs=  d.executeQuery(sql,u.getAdminName(),u.getAdminPwd());
		Admin u1 = null;
		try {
			while(rs.next())
			{
			  u1 = new Admin(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			d.closeConnection();
		}
		return u1;
		
	}

	@Override
	public List<Notice> getlist(int currentpage, int pagesize) {
		d.openConnection();
		String sql = "select t.id,t.name,t.content,t.times  from "+ 
		  " (select ROW_NUMBER()over(order by id) rn,e.id,e.name,e.content,e.times from notice e ) t  where t.rn between ? and ?  ";
		List<Notice> list = new ArrayList<Notice>();
        int a = (currentpage-1)*pagesize+1;
        int b = currentpage*pagesize;
        ResultSet rs = d.executeQuery(sql,a,b);
        try {
			while(rs.next())
			{   
				
				Notice e = new Notice(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				list.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
        {
			d.closeConnection();
        }
		return list;
		
	}

	@Override
	public int countpage1() {
		d.openConnection();
		String sql = "select count(*) from Notice";
		ResultSet rs = d.executeQuery(sql);
		int countpage = 0;
		try {
			while(rs.next())
			{
				countpage = rs.getInt(1);
				System.out.print(countpage);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			d.closeConnection();
		}
		if(countpage%5==0)
		{
			countpage = countpage/5;
		}
		else
			countpage = countpage/5+1;
		return countpage;
	}


	public Notice select(int a) {
		d.openConnection();
		String sql = "select * from notice where id = ?";
		ResultSet rs = d.executeQuery(sql, a);
		try {
			while(rs.next())
			{   
				
				return new Notice(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			d.closeConnection();
		}
		return null;
	
	}

	@Override
	public int update(Notice n) {
		d.openConnection();
		int a = 0;
		String sql = "update notice set name =?,content =? ,times =?  where id =? ";
	    a = d.executeUpdate(sql, n.getNoticeName(),n.getNoticeContent(),n.getNoticeTimes(),n.getNoticeId());
	    d.closeConnection();
		return a;
	}

	public void delete(int a) {
		d.openConnection();
		String sql = "delete from notice where id = ?";
		d.executeQuery(sql, a);
		 d.closeConnection();
	}

	
	public void newone(Notice n) {
		d.openConnection();
		String sql = "insert notice values(?,?,?)";
	    d.executeUpdate(sql, n.getNoticeName(),n.getNoticeContent(),n.getNoticeTimes());
	    d.closeConnection();

	}

	@Override
	public List<Notice> getlist7() {
		d.openConnection();
		String sql = "select top 10 * from notice";
		List<Notice> list = new ArrayList<Notice>();
		ResultSet rs = d.executeQuery(sql);
		try {
			while(rs.next())
			{   
				Notice e = new Notice(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				list.add(e);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			d.closeConnection();
		}
		return list;
	}
	 

}
