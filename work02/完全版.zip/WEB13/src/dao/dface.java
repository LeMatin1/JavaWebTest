package dao;

import java.util.List;

import pojo.Admin;
import pojo.Notice;

public interface dface {
	 Admin login(Admin u);
	 List<Notice> getlist(int currentpage,int pagesize);
	 int countpage1();
	 Notice select(int a);
	 int update(Notice n);
     void delete(int a );
     void newone(Notice n);
     List<Notice> getlist7();
}
