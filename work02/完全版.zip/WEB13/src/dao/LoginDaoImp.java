package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import DBUtils.DBUtils;
import dao.LoginDao;
import pojo.Users;


public class LoginDaoImp implements LoginDao{
	public Users Login(Users user){
		Users users = null;
		try{
			DBUtils.openConnection();
			String sql = "select * from users where name = ? and pwd = ?";
			ResultSet rs = DBUtils.executeQuery(sql, user.getUsersName(),user.getUsersPwd());
			if(rs.next()){
				users = new Users(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
						rs.getInt(6),rs.getString(7),rs.getString(8),rs.getString(9),
						rs.getString(10),rs.getString(11),rs.getInt(12));
			}else{
				System.out.println(rs.getInt(1));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBUtils.closeConnection();
		}
		return users;
	}
}

	
