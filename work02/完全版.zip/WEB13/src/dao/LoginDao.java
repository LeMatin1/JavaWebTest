package dao;


import pojo.Users;

public interface LoginDao {
	public Users Login(Users user);
}
