package pojo;

/**
 * ��Ʒ��
 * @author Administrator
 *
 */
public class Menus {

	int    menusId;
	@Override
	public String toString() {
		return "Menus [menusId=" + menusId + ", menusName=" + menusName + ", menusTypes=" + menusTypes
				+ ", menusBurden=" + menusBurden + ", menusBrief=" + menusBrief + ", menusPrice=" + menusPrice
				+ ", menusSums=" + menusSums + ", menusPrice1=" + menusPrice1 + ", sums1=" + sums1 + ", imgpath="
				+ imgpath + "]";
	}

	String menusName;
	Types  menusTypes;
	String menusBurden;  //ԭ��
	String menusBrief;   //˵��
	float  menusPrice;   //�г��� ���ȿ��ܴ������� �ɸ�double����
	int    menusSums;	 //�г�����������
	float  menusPrice1;  //��Ա��
	int    sums1;  		 //��Ա����������
	String imgpath;      //ͼƬ���·��
	
	public Menus(int menusId, String menusName, Types menusTypes, String menusBurden, String menusBrief,
			float menusPrice, int menusSums, float menusPrice1, int sums1, String imgpath) {
		super();
		this.menusId = menusId;
		this.menusName = menusName;
		this.menusTypes = menusTypes;
		this.menusBurden = menusBurden;
		this.menusBrief = menusBrief;
		this.menusPrice = menusPrice;
		this.menusSums = menusSums;
		this.menusPrice1 = menusPrice1;
		this.sums1 = sums1;
		this.imgpath = imgpath;
	}
	
	public Menus( String menusName, Types menusTypes, String menusBurden, String menusBrief,
			float menusPrice,  float menusPrice1, String imgpath) {
		super();
		this.menusName = menusName;
		this.menusTypes = menusTypes;
		this.menusBurden = menusBurden;
		this.menusBrief = menusBrief;
		this.menusPrice = menusPrice;
		this.menusPrice1 = menusPrice1;
		this.imgpath = imgpath;
	}
	public Menus( int menusId,String menusName,  String menusBurden, float menusPrice,  
				float menusPrice1,String menusBrief, String imgpath) {
		super();
		this.menusId = menusId;
		this.menusName = menusName;
		this.menusBurden = menusBurden;
		this.menusBrief = menusBrief;
		this.menusPrice = menusPrice;
		this.menusPrice1 = menusPrice1;
		this.imgpath = imgpath;
	}
	public Menus( int menusId,String menusName, Types menusTypes, String menusBurden, String menusBrief,
			float menusPrice,  float menusPrice1, String imgpath) {
		super();
		this.menusId = menusId;
		this.menusName = menusName;
		this.menusTypes = menusTypes;
		this.menusBurden = menusBurden;
		this.menusBrief = menusBrief;
		this.menusPrice = menusPrice;
		this.menusPrice1 = menusPrice1;
		this.imgpath = imgpath;
	}

	public Menus() {
		super();
	}

	public int getMenusId() {
		return menusId;
	}

	public void setMenusId(int menusId) {
		this.menusId = menusId;
	}

	public String getMenusName() {
		return menusName;
	}

	public void setMenusName(String menusName) {
		this.menusName = menusName;
	}

	public Types getMenusTypes() {
		return menusTypes;
	}

	public void setMenusTypes(Types menusTypes) {
		this.menusTypes = menusTypes;
	}

	public String getMenusBurden() {
		return menusBurden;
	}

	public void setMenusBurden(String menusBurden) {
		this.menusBurden = menusBurden;
	}

	public String getMenusBrief() {
		return menusBrief;
	}

	public void setMenusBrief(String menusBrief) {
		this.menusBrief = menusBrief;
	}

	public float getMenusPrice() {
		return menusPrice;
	}

	public void setMenusPrice(float menusPrice) {
		this.menusPrice = menusPrice;
	}

	public int getMenusSums() {
		return menusSums;
	}

	public void setMenusSums(int menusSums) {
		this.menusSums = menusSums;
	}

	public float getMenusPrice1() {
		return menusPrice1;
	}

	public void setMenusPrice1(float menusPrice1) {
		this.menusPrice1 = menusPrice1;
	}

	public int getSums1() {
		return sums1;
	}

	public void setSums1(int sums1) {
		this.sums1 = sums1;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}
	
	
	
	
	
	
	
}
