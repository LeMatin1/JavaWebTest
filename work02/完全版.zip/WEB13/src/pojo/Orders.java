package pojo;


/**
 * ������
 * @author Administrator
 *
 */
public class Orders {
	
	int ordersId;
	Users ordersUsers;
	Menus ordersmenus;
	int ordersMenusum;
	String ordersTimes;
	int  ordersDelivery; //�Ƿ����� 1�� 0��	
		
	public Orders() {
		super();
	}

	public Orders(int ordersId, Users ordersUsers, Menus ordersmenus, int ordersMenusum, String ordersTimes,
			int ordersDelivery) {
		super();
		this.ordersId = ordersId;
		this.ordersUsers = ordersUsers;
		this.ordersmenus = ordersmenus;
		this.ordersMenusum = ordersMenusum;
		this.ordersTimes = ordersTimes;
		this.ordersDelivery = ordersDelivery;
	}

	public int getordersId() {
		return ordersId;
	}

	public void setordersId(int ordersId) {
		this.ordersId = ordersId;
	}

	public Users getordersUsers() {
		return ordersUsers;
	}

	public void setordersUsers(Users ordersUsers) {
		this.ordersUsers = ordersUsers;
	}

	public Menus getordersmenus() {
		return ordersmenus;
	}

	public void setordersmenus(Menus ordersmenus) {
		this.ordersmenus = ordersmenus;
	}

	public int getordersMenusum() {
		return ordersMenusum;
	}

	public void setordersMenusum(int ordersMenusum) {
		this.ordersMenusum = ordersMenusum;
	}

	public String getordersTimes() {
		return ordersTimes;
	}

	public void setordersTimes(String ordersTimes) {
		this.ordersTimes = ordersTimes;
	}

	public int getordersDelivery() {
		return ordersDelivery;
	}

	public void setordersDelivery(int ordersDelivery) {
		this.ordersDelivery = ordersDelivery;
	}
	
	
	
}
