package pojo;


/**
 * �˵�����
 * @author Administrator
 *
 */
public class Types {

	int    typesId;
	String typesName;
	
	public Types(int typesId, String typesName) {
		super();
		this.typesId = typesId;
		this.typesName = typesName;
	}
	public Types(int typesId) {
		super();
		this.typesId = typesId;
	}

	public Types() {
		super();
	}

	public int getTypesId() {
		return typesId;
	}

	public void setTypesId(int typesId) {
		this.typesId = typesId;
	}

	public String getTypesName() {
		return typesName;
	}

	public void setTypesName(String typesName) {
		this.typesName = typesName;
	}
	
	
	
}
