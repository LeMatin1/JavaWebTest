package pojo;

/**
 * �û���
 * @author Administrator
 *
 */
public class Users {

	 int    usersId;
	 String usersName;
	 String usersPwd;
	 String usersRealname;
	 String usersSex;
	 int    usersage;
	 String usersCard;     //����֤��
	 String usersAddress;
	 String usersPhone;
	 String usersEmail;
	 String userscode;     //��������
	 int    type;
	 
	 
	 
	 
	public Users() {
		super();
	}
	
	
	
	public Users(String usersName, String usersPwd, String usersRealname, String usersSex, int usersage,
			String usersCard, String usersAddress, String usersPhone, String usersEmail, String userscode) {
		super();
		this.usersName = usersName;
		this.usersPwd = usersPwd;
		this.usersRealname = usersRealname;
		this.usersSex = usersSex;
		this.usersage = usersage;
		this.usersCard = usersCard;
		this.usersAddress = usersAddress;
		this.usersPhone = usersPhone;
		this.usersEmail = usersEmail;
		this.userscode = userscode;
	}



	public Users(String usersName, String usersPwd) {
		super();
		this.usersName = usersName;
		this.usersPwd = usersPwd;
	}

	public Users(int usersId, String usersName, String usersPwd, String usersRealname, String usersSex, int usersage,
			String usersCard, String usersAddress, String usersPhone, String usersEmail, String userscode, int type) {
		super();
		this.usersId = usersId;
		this.usersName = usersName;
		this.usersPwd = usersPwd;
		this.usersRealname = usersRealname;
		this.usersSex = usersSex;
		this.usersage = usersage;
		this.usersCard = usersCard;
		this.usersAddress = usersAddress;
		this.usersPhone = usersPhone;
		this.usersEmail = usersEmail;
		this.userscode = userscode;
		this.type = type;
	}
	public int getUsersId() {
		return usersId;
	}
	public void setUsersId(int usersId) {
		this.usersId = usersId;
	}
	public String getUsersName() {
		return usersName;
	}
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	public String getUsersPwd() {
		return usersPwd;
	}
	public void setUsersPwd(String usersPwd) {
		this.usersPwd = usersPwd;
	}
	public String getUsersRealname() {
		return usersRealname;
	}
	public void setUsersRealname(String usersRealname) {
		this.usersRealname = usersRealname;
	}
	public String getUsersSex() {
		return usersSex;
	}
	public void setUsersSex(String usersSex) {
		this.usersSex = usersSex;
	}
	public int getUsersage() {
		return usersage;
	}
	public void setUsersage(int usersage) {
		this.usersage = usersage;
	}
	public String getUsersCard() {
		return usersCard;
	}
	public void setUsersCard(String usersCard) {
		this.usersCard = usersCard;
	}
	public String getUsersAddress() {
		return usersAddress;
	}
	public void setUsersAddress(String usersAddress) {
		this.usersAddress = usersAddress;
	}
	public String getUsersPhone() {
		return usersPhone;
	}
	public void setUsersPhone(String usersPhone) {
		this.usersPhone = usersPhone;
	}
	public String getUsersEmail() {
		return usersEmail;
	}
	public void setUsersEmail(String usersEmail) {
		this.usersEmail = usersEmail;
	}
	public String getUserscode() {
		return userscode;
	}
	public void setUserscode(String userscode) {
		this.userscode = userscode;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

	 
	 
}
