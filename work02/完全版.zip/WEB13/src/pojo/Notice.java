package pojo;

/**
 * ������
 * @author Administrator
 *
 */
public class Notice {

	int    noticeId;
	String noticeName;
	String noticeContent;  //��������
	String noticeTimes;
	
	
	
	public Notice() {
		super();
	}
	
	public Notice(int noticeId, String noticeName, String noticeContent, String noticeTimes) {
		super();
		this.noticeId = noticeId;
		this.noticeName = noticeName;
		this.noticeContent = noticeContent;
		this.noticeTimes = noticeTimes;
	}

	public Notice(String noticeName, String noticeContent, String noticeTimes) {
		super();
		this.noticeName = noticeName;
		this.noticeContent = noticeContent;
		this.noticeTimes = noticeTimes;
	}

	public int getNoticeId() {
		return noticeId;
	}

	public void setNoticeId(int noticeId) {
		this.noticeId = noticeId;
	}

	public String getNoticeName() {
		return noticeName;
	}

	public void setNoticeName(String noticeName) {
		this.noticeName = noticeName;
	}

	public String getNoticeContent() {
		return noticeContent;
	}

	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}

	public String getNoticeTimes() {
		return noticeTimes;
	}

	public void setNoticeTimes(String noticeTimes) {
		this.noticeTimes = noticeTimes;
	}
	
	
	
	
	
}
