package serverImp;

import dao.LoginDao;
import dao.LoginDaoImp;
import pojo.Users;
import server.LoginServer;


public class LoginServerImp implements LoginServer{
	private LoginDao  user1= new LoginDaoImp();
	public Users Login(Users user){
		return user1.Login(user);
	}
}
