package serverImp;

import dao.RegisterDao;
import dao.RegisterDaoImpl;
import pojo.Users;
import server.RegisterService;

public class RegisterServiceImpl implements RegisterService{
	RegisterDao user1=new RegisterDaoImpl();
	public void register(Users user){
		user1.register(user);
	}
}
