package serverImp;

import java.util.List;

import dao.OrdersDao;
import dao.OrdersDaoImp;
import pojo.Orders;
import server.OrdersServer;

public class OrderServerImp implements OrdersServer {

	OrdersDao oDao = new OrdersDaoImp();
	
	@Override
	public int ordersCount() {
		
		return oDao.ordersCount();
	}

	@Override
	public List<Orders> ordersList(int currentPage, int pageSize) {
		
		int begin = (currentPage-1)*pageSize+1;
		int end = currentPage*pageSize;
		
		return oDao.ordersList(begin, end);
	}

	@Override
	public void ordersAdd(Orders orders) {
		oDao.ordersAdd(orders);
	}

	@Override
	public void ordersDelete(int id) {
		oDao.ordersDelete(id);
		
	}

	@Override
	public void ordersConfirm(Orders orders) {
		oDao.ordersConfirm(orders);
		
	}

	@Override
	public List<Orders> ordersselectUsersId(int id) {
		return oDao.ordersselectUsersId(id);
	}

	@Override
	public List<Orders> ordersselectMenusName(String name) {
		return oDao.ordersselectMenusName(name);
	}

	@Override
	public List<Orders> ordersselectOrdersTimes(String time) {
		return oDao.ordersselectOrdersTimes(time);
	}

	@Override
	public List<Orders> ordersDaySum(String time) {
		return oDao.ordersDaySum(time);
	}

	@Override
	public List<Orders> orderHomePage() {
		return oDao.orderHomePage();
	}

	@Override
	public List<Orders> ordersselectMenusName(String name, int id) {
		return oDao.ordersselectMenusName(name, id);
	}

	@Override
	public List<Orders> ordersselectOrdersTimes(String time, int id) {
		// TODO Auto-generated method stub
		return oDao.ordersselectOrdersTimes(time, id);
	}

	@Override
	public List<Orders> ordersselectOrdersDelivery(int Delivery,int id) {
		return oDao.ordersselectOrdersDelivery(Delivery,id);
	}
	

}
