package serverImp;

import java.util.List;

import dao.MenusDao;
import dao.MenusDaoImpl;
import pojo.Menus;
import server.MenusService;


public class MenusServiceImpl implements MenusService {

	MenusDao md = new MenusDaoImpl();
		public void addMenu(Menus menus) {
			md.addMenu(menus);
			
		}
		
		public List<Menus> getMenusList() {
			
			return md.getMenusList();
		}

		
		public void deleteMenu(int menusId) {
			md.deleteMenu(menusId);
			
		}

		
		public void updateMenu(Menus menus) {
			md.updateMenu(menus);
			
		}
}
