package serverImp;

import dao.UsersDao;
import dao.UsersDaoImp;
import server.UsersServer;

public class UsersServerImp implements UsersServer{
	private UsersDao ud = new UsersDaoImp();
	
	public void Deleteuser(int id){
		ud.Deleteuser(id);
	}
}
