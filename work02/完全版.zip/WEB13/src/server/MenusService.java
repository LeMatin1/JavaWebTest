package server;

import pojo.Menus;
import java.util.*;

public interface MenusService {
	public void addMenu(Menus menus);
	public List<Menus> getMenusList();
	public void deleteMenu(int menusId);
	public void updateMenu(Menus menus);
}
