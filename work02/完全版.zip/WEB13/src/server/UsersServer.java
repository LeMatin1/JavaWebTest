package server;

public interface UsersServer {
	public void Deleteuser(int id);
}
