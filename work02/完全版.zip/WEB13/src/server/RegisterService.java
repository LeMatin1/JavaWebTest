package server;


import pojo.Users;

public interface RegisterService {
	public void register(Users user);
}
