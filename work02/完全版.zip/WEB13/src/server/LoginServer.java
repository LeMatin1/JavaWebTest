package server;

import pojo.Users;

public interface LoginServer {
    public Users Login(Users user);
}
