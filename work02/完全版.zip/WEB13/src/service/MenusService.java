package service;

import pojo.Menus;
import java.util.*;

public interface MenusService {
	public void addMenu(Menus menus);
	public List<Menus> getMenusPageList(int currentPage, int pageSize);
	public void deleteMenu(int menusId);
	public void updateMenu(Menus menus);
	public int getMenusCount();
	public List<Menus> getMenusList();
	public Menus getMenus1(int id);
}
