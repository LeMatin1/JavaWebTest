package service;

import pojo.Admin;

public interface AdminService {
	public void updateAdmin( Admin admin);
}
