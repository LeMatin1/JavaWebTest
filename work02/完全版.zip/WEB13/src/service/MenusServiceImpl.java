package service;

import java.util.List;

import dao.MenusDao;
import dao.MenusDaoImpl;
import pojo.Menus;
import service.MenusService;

public class MenusServiceImpl implements MenusService {

	MenusDao md = new MenusDaoImpl();
		public void addMenu(Menus menus) {
			md.addMenu(menus);
			
		}
		
		public List<Menus> getMenusPageList(int currentPage, int pageSize) {
			
			return md.getMenusPageList(currentPage, pageSize);
		}

		
		public void deleteMenu(int menusId) {
			md.deleteMenu(menusId);
			
		}

		
		public void updateMenu(Menus menus) {
			md.updateMenu(menus);
			
		}


		public int getMenusCount() {
		
			return md.getMenusCount();
		}

		
		public List<Menus> getMenusList() {
			
			return md.getMenusList();
		}

	
		public Menus getMenus1(int id) {
		
			return md.getMenus1(id);
		}
}
