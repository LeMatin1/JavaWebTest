package service;

import java.util.*;

import pojo.Menus;
import pojo.Types;

public interface TypeService {
	public List<Types> getTypes();
	public void addTypes(String typesName);
	public void deleteType(int typesId);
	public void updateType(Types types);
}
