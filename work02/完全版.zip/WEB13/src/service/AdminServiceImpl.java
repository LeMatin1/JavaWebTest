package service;

import dao.AdminDao;
import dao.AdminDaoImpl;
import pojo.Admin;

public class AdminServiceImpl implements AdminService {

	
	public void updateAdmin(Admin admin) {
		
		AdminDao ad = new AdminDaoImpl();
				ad.updateAdmin(admin);
	}

}
