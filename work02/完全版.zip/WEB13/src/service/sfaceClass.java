package service;

import java.util.List;

import dao.dfaceClass;
import pojo.Admin;
import pojo.Notice;

public class sfaceClass implements sface{
	 dfaceClass d = new dfaceClass();

	public Admin login(Admin u) {
		
		return d.login(u);
	}

	public List<Notice> getlist(int currentpage, int pagesize) {
		
		return d.getlist(currentpage, pagesize);
	}


	public int countpage1() {
		
		return d.countpage1();
	}

	public Notice select(int a) {
		
		return d.select(a);
	}

	@Override
	public int update(Notice n) {
		
		return d.update(n);
	}

	@Override
	public void delete(int a) {
		d.delete(a);
	}


	public void newone(Notice n) {
		d.newone(n);
		
	}

	@Override
	public List<Notice> getlist7() {
		
		return d.getlist7();
	}
	
     
}
