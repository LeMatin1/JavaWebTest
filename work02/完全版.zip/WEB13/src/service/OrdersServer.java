package service;

import java.util.List;

import pojo.Orders;

public interface OrdersServer {

	int ordersCount();
	List<Orders> ordersList(int currentPage,int pageSize);

	List<Orders> ordersselectUsersId(int id);
	List<Orders> ordersselectMenusName(String name);
	List<Orders> ordersselectOrdersTimes(String time);
	List<Orders> ordersDaySum(String time);   //ʵ�ּ��㵥��Ӫҵ��
	
	void ordersAdd(Orders orders);
	void ordersDelete(int id);
	void ordersConfirm(Orders orders);
	
}
