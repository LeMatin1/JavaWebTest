package service;

import java.util.List;

import dao.TypeDao;
import dao.TypeDaoImpl;
import pojo.Menus;
import pojo.Types;
import service.MenusService;
import service.TypeService;

public class TypeServiceImpl implements TypeService {

	TypeDao td = new TypeDaoImpl();
	public List<Types> getTypes() {
		
		return td.getTypes();
	}
	
	public void addTypes(String typesName) {
		td.addTypes(typesName);
		
	}

	public void deleteType(int typesId)
	{
		td.deleteType(typesId);
	}
	public void updateType(Types types)
	{
		td.updateType(types);
	}
}
