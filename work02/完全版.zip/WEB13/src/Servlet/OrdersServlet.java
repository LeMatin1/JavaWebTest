package Servlet;

import java.io.IOException;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MenusDao;
import dao.MenusDaoImpl;
import pojo.Menus;
import pojo.Orders;
import pojo.Users;
import server.OrdersServer;
import serverImp.OrderServerImp;



@WebServlet("/orders")
public class OrdersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final OrdersServer os = new OrderServerImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String opType = request.getParameter("opType");
		String result = "";
		
		System.out.println(opType+"1");
		
		if("list".equals(opType)){
			result = ordersList(request);
		}else if("HomepageSubmit".equals(opType)){
			//������ҳ��ȫ���ύ����
			result = orderAdd(request); 
			
		}else if("delete".equals(opType)){
			//����ɾ������ ��δʵ��
			
		}else if("confirm".equals(opType)){
			//����ȷ�϶��������� ��ʱδʵ��
			
		}else if("select".equals(opType)){
			//��̨�Ĳ�ѯ
			result = ordersSelect(request);
			
		}else if("daySum".equals(opType)){
			result = ordersDay(request);
		}else if("Homepage".equals(opType)){
			//����������ҳ����������
			result = ordersHomepage(request);
		}else if("init".equals(opType)){
			//ҳ���һ�η��ʵ�ʱ�� ����ʷ��������session�� 
			result = ordersInit(request);
		}else if("HomepageDeleteAll".equals(opType)){
			//ȫ��ȡ��
			session.removeAttribute("carList");
			session.removeAttribute("littleCarlist");
			result = "homepage";
		}else if("HomepageDelete".equals(opType)){
			//ȡ��������Ʒ
			result = orderCancal(request);
		}else if("HomepageSelect".equals(opType)){
			//ǰ�˶������
			result= HomepageSelect(request);
			
		}else if("AllfromId".equals(opType)){
			//id����ȫ������
			result =AllfromId(request);
		}else if("selectDelivery".equals(opType)){
			//�Ƿ����Ͳ���
			result = hasDelivery(request);
		}
		
		request.getRequestDispatcher(result).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	/**
	 * �����ύ
	 * @param request
	 * @return
	 */
	private String orderAdd(HttpServletRequest request) {
		HttpSession session = request.getSession();
		List<Orders> carList = (List<Orders>) session.getAttribute("carList"); 
		
		Users user = (Users) session.getAttribute("user");
		if(user==null){
			return "PleasLogin.jsp";
		}
		for(int i =0;i<carList.size();i++){
			Orders orders = carList.get(i);  //ֻȡͷ 
			orders.setordersUsers(user);  //����һ���û�ID ���� �����Ѿ����
			os.ordersAdd(orders);
			//��Ƿȱһ������ ���� ��Ʒ�����������
		}
		carList.clear();  //��չ��ﳵ
		session.removeAttribute("carList");
		session.removeAttribute("littleCarlist"); //�Ƴ����ﳵ���� ��������Ҳ������

		return "homepage";
	}
	
	
	/**
	 * ���ַ�ʽ���Ҽ�¼ ���
	 * @param request
	 * @return
	 */
	private String ordersSelect(HttpServletRequest request) {
		
		//��ȡ����
		String id =request.getParameter("conditionId");
		String name =request.getParameter("conditionName");
		String time = request.getParameter("conditionMenu");
		
		
		List<Orders> list = new ArrayList<Orders>();
		
		if(id!=null && !id.equals("")){
			//����ID����
			int userId = Integer.parseInt(id);
			list = os.ordersselectUsersId(userId);
			
		}else if(name!=null && !name.equals("")){
			
			//��Ӣ�Ĳ���תΪ����
			try {
				byte[] bytes = null;
				bytes = name.getBytes("ISO8859-1");
				name = new String(bytes, "UTF-8");
				
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			
			//���ղ�Ʒ������
			list = os.ordersselectMenusName(name);
			System.out.println(name);
			
		}else if(time!=null && !time.equals("")){
			//����ʱ�����
			list = os.ordersselectOrdersTimes(time);
			System.out.println(time);
		}
		
		System.out.println(list);
		request.setAttribute("ordersList", list);
		
		return "orderSelect.jsp";
	}

	/**
	 * ��ҳ��ѯ
	 * @param request
	 * @return
	 */
	private String ordersList(HttpServletRequest request) {
		int pageSize = 5;
		int currentPage = 1;
		String currentPages = request.getParameter("currentPage");
		
		//��ȡ����
		int num = os.ordersCount();
		int maxPage = num%pageSize==0?num/pageSize:num/pageSize+1;
		
		if(currentPages!=null){
			currentPage = Integer.parseInt(currentPages);
		}
		
		List<Orders> list = os.ordersList(currentPage, pageSize);

		request.setAttribute("ordersList", list);
		request.setAttribute("currentPage",currentPages );
		request.setAttribute("maxPage", maxPage);
		return "orderList.jsp";
		
	}
	
	
	/**
	 * ����Ӫҵ�� Ŀǰ������д��  �ɲ���localdate
	 * @param request
	 * @return
	 */
	private String ordersDay(HttpServletRequest request) {
		
		LocalDate ld = LocalDate.now();
		String times = ld.toString();
		System.out.println(times);
		
		times = "2019-7-12"; //������
		
		List<Orders> list = new ArrayList<Orders>();
		list = os.ordersDaySum(times);
		
		System.out.println(list);
		request.setAttribute("totalList", list);
		
		return "orderTotal.jsp";
	}


	/**
	 * ����������ҳ�����Ӳ�Ʒ����
	 * @param request
	 * @return
	 */
	private String ordersHomepage(HttpServletRequest request) {

		MenusDao md = new MenusDaoImpl();
		
		HttpSession session = request.getSession();
		float totalMoney = (float) session.getAttribute("totalMoney"); //��ȡ�ܽ��
		int totalNum = (int) session.getAttribute("totalNum");   //������
			
		List<Orders> carList = (List<Orders>) session.getAttribute("carList");   //����������Ϊϵͳ��ȷ�� ǿת�İ�ȫ��
		
		String menusId = request.getParameter("menusId");
		int id = Integer.parseInt(menusId);
		
		Menus me = md.getMenus(id); //�����ݿ����õ��˵�ȫ����Ϣ
		
		if(me!=null){
			int value=1;  //Ĭ������
			int i =0;
			
			for(i=0;i<carList.size();i++){
				
				if(carList.get(i).getordersmenus().getMenusId() == me.getMenusId()){
				
					value = carList.get(i).getordersMenusum();  //��ȡ��ǰ���ﳵ�� ���ڲ�Ʒ������
					carList.get(i).setordersMenusum(++value);
					
					totalMoney += me.getMenusPrice1();
					totalNum++;
					break;
				}	
			}
			
			if(i==carList.size()){
				Orders orders = new Orders();
				
				orders.setordersmenus(me);
				orders.setordersMenusum(value);
				orders.setordersDelivery(1);
				orders.setordersTimes("2019-8-8");
				
				carList.add(orders);

				totalMoney += me.getMenusPrice1();
				totalNum++;
			}
			
			session.setAttribute("carList", carList);
			session.setAttribute("totalMoney", totalMoney);
			session.setAttribute("totalNum", totalNum);
						
			List<Orders> littleCarlist = new ArrayList<Orders>(); //����һ��С���ﳵ ��������ҳ֮�� ֻȡ��ǰ������
			for(i=0;i<carList.size();i++){
				littleCarlist.add(carList.get(i));
				if(i==2){
					break;
				}
			}
			session.setAttribute("littleCarlist", littleCarlist);
			
		}
		
		
		return "homepage";
	}
	
	/**
	 * ��һ�η���
	 * @param request
	 * @return
	 */
	private String ordersInit(HttpServletRequest request) {

		if(request.getSession().getAttribute("carList")==null){
			List<Orders> carList = new ArrayList<Orders>(); //��ʼ�����ﳵ 
			request.getSession().setAttribute("carList", carList);
			Float totalMoney = 0.0f;						//�ܽ��
			request.getSession().setAttribute("totalMoney", totalMoney);
			int totalNum = 0;								//������
			request.getSession().setAttribute("totalNum", totalNum);
			
		}
				
		List<Orders> list = os.orderHomePage();
		request.getSession().setAttribute("ordersList", list);
		
		System.out.println("init");
		return "Noticeservlet?opType=init";
	}
	
	/**
	 * ȡ��������Ʒ
	 * @param request
	 * @return
	 */
	private String orderCancal(HttpServletRequest request) {
		String ids = request.getParameter("menusId");
		int id = Integer.parseInt(ids);

		//��ȡ����
		HttpSession session = request.getSession();
		List<Orders> carList = (List<Orders>) session.getAttribute("carList");   //����������Ϊϵͳ��ȷ�� ǿת�İ�ȫ��
		float totalMoney = (float) session.getAttribute("totalMoney"); //��ȡ�ܽ��
		int totalNum = (int) session.getAttribute("totalNum");   //������
		
		
		for(int i =0 ;i<carList.size();i++){
			
			if(carList.get(i).getordersmenus().getMenusId()==id){
				//ɾ���������� ��ȥС��
				Orders orders = carList.remove(i);
				int num = orders.getordersMenusum();
				float price = orders.getordersmenus().getMenusPrice1();
				
				totalNum-=num;
				totalMoney-=price*num;
				
				session.setAttribute("carList", carList);
				session.setAttribute("totalMoney", totalMoney);
				session.setAttribute("totalNum", totalNum);
				break;
			}
			
		}
		
		return "homepage";
	}

	/**
	 * ǰ�˲�ѯ��Ϣ
	 * @param request
	 * @return
	 */
	private String HomepageSelect(HttpServletRequest request) {
		
		
		Users user = (Users) request.getSession().getAttribute("user");
		//��ȡ����
		String name =request.getParameter("conditionName");
		String time = request.getParameter("conditionTime");
		
		
		List<Orders> list = new ArrayList<Orders>();
		
		 if(name!=null && !name.equals("")){
			
			//��Ӣ�Ĳ���תΪ����
			try {
				byte[] bytes = null;
				bytes = name.getBytes("ISO8859-1");
				name = new String(bytes, "UTF-8");
				
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			
			//���ղ�Ʒ������
			list = os.ordersselectMenusName(name,user.getUsersId());
			System.out.println(list);
			System.out.println(name);
			
		}else if(time!=null && !time.equals("")){
			//����ʱ�����
			list = os.ordersselectOrdersTimes(time,user.getUsersId());
			System.out.println(list);
			System.out.println(time);
		}
		
		System.out.println("asd");
		request.setAttribute("HomepageSelectList", list);
		
		return "Query.jsp";
	}

	private String AllfromId(HttpServletRequest request) {
		
		Users user = (Users) request.getSession().getAttribute("user");
		//��ȡ����
		
		List<Orders> list = new ArrayList<Orders>();
		
		 if(user!=null){
			
			 list = os.ordersselectUsersId(user.getUsersId());
			
		}
		
		request.setAttribute("HomepageSelectList", list);
		
		return "Query.jsp";
	}

	private String hasDelivery(HttpServletRequest request) {
	
		Users user = (Users) request.getSession().getAttribute("user");
		//��ȡ����
		String status = request.getParameter("delivery");
		int delivery = Integer.parseInt(status);
		
		List<Orders> list = new ArrayList<Orders>();
		
		 if(user!=null){
			
			 list = os.ordersselectOrdersDelivery(delivery,user.getUsersId());
			
		}
		
		 
		request.setAttribute("HomepageSelectList", list);
		
		return "Query.jsp";
	}

}





