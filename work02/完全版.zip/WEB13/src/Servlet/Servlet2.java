package Servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import pojo.Menus;
import pojo.Types;
import service.MenusService;
import service.MenusServiceImpl;
import service.TypeService;
import service.TypeServiceImpl;



@WebServlet("/servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String  id = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("UTF-8");
		TypeService ts = new TypeServiceImpl();
		MenusService ms = new MenusServiceImpl();
		List<Types> tList = ts.getTypes();			
		request.setAttribute("tList", tList);
		List<Menus> mList = ms.getMenusList();
		request.setAttribute("mList", mList);
		String opType = request.getParameter("opType");
		String result = "";
		if("homepageMenus".equals(opType)){
			mList = ms.getMenusList();
			
			List<Menus> mListCopy = new ArrayList<Menus>();
			for(int i=0;i<6;i++){
				mListCopy.add(mList.get(i));
			}
			result = "Homepage.jsp";
			request.getSession().setAttribute("mList",mListCopy);
		}
		else if("foodMsg".equals(opType)){
			 tList = ts.getTypes();			
			request.setAttribute("tList", tList);
			 mList = getMenuPageList(request);
			request.setAttribute("mList", mList);
			result = "foodMsg.jsp";
		}else if("foodTypeMsg".equals(opType)){
			tList = ts.getTypes();
			request.setAttribute("tList", tList);
			 mList = ms.getMenusList();
			request.setAttribute("mList", mList);	
			result = "foodTypeMsg.jsp";			
		}else if("toAddFood".equals(opType)){
			  result=toAddFood(request);
		}else if("addFood".equals(opType)){			
			result = addFood(request);
		}else if("addFoodType".equals(opType)){
			String typesName =  request.getParameter("foodType");
			System.out.println(typesName);
			result = addType(request,typesName);
		}else if("deteleFood".equals(opType)){
			String menusId = request.getParameter("menusId");
			result = deteleFood(request,menusId);
		}else if("toUpdateFood".equals(opType)){
			String menusId1 =  request.getParameter("menusId");
			int menusId = Integer.parseInt(menusId1);
			Menus menus = ms.getMenus1(menusId);			
			request.setAttribute("menus", menus);
			result = toUpdateFood(request );
		}else if("updateFood".equals(opType)){	
			result = updateFood(request);
		}else if("deleteType".equals(opType)){
			System.out.println("ok");
			String typesId = request.getParameter("typesId");
			result = deleteType(request,typesId);
		}else if("toUpdatetype".equals(opType)){
			String typesId =  request.getParameter("typesId");
			request.setAttribute("typesId", typesId);
			result = toUpdateType(request );
		}
		else if("updateType".equals(opType)){
			String typesId = request.getParameter("typesId");
			
			result = updateTypes(request,typesId);
		}
		

		request.getRequestDispatcher(result).forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	public List<Menus> getMenuPageList(HttpServletRequest request){
		MenusService ms = new MenusServiceImpl();
		//��ȡ�����еĵ�ǰ�ڼ�ҳ�������ȡ������Ĭ�ϵ�һҳ
		int currentPage = 1;
		String currentPageStr = request.getParameter("currentPage");
		if(currentPageStr !=null){
			currentPage = Integer.parseInt(currentPageStr);
		}
		//��ȡ�����е�ÿҳ��ʾ�ı����������ȡ������Ĭ��ÿҳ5��
		int pageSize = 5;
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr!=null){
			pageSize = Integer.parseInt(pageSizeStr);
		}
		//��ȡ������
		int count = ms.getMenusCount();
		//��ȡ��ҳ����
		List<Menus> mList = ms.getMenusPageList(currentPage, pageSize);
		//��ȡ��ҳ�����������������ÿҳ����  ���þ�������ҳ��=������/ÿҳ����    ������ҳ��=������/ÿҳ���� + 1
		int pageCount = count % pageSize!=0?count/pageSize+1:count/pageSize;
		
		//System.out.println("pageCount:"+pageCount);
		//���浱ǰҳ����ÿҳ��������ѯ�Ľ��
		HttpSession session = request.getSession();
		session.setAttribute("currentPage", currentPage);
		session.setAttribute("pageCount", pageCount);
		session.setAttribute("mList", mList);
		
		return mList;
	}
	public String toAddFood(HttpServletRequest request){
		TypeService ts = new TypeServiceImpl();
		MenusService ms = new MenusServiceImpl();
		List<Types> tList = ts.getTypes();			
		request.setAttribute("tList", tList);
		List<Menus> mList = ms.getMenusList();
		request.setAttribute("mList", mList);
		
		return "addFood.jsp";		
	}
	public String addFood(HttpServletRequest request){
		MenusService ms = new MenusServiceImpl();
		String menusName = request.getParameter("menusName");
		String menusBurden = request.getParameter("menusBurden");
		String menusPrice0 = request.getParameter("menusPrice");
		float menusPrice = Float.parseFloat(menusPrice0);
		String menusPrice11 = request.getParameter("menusPrice1");
		float menusPrice1 = Float.parseFloat(menusPrice11);
		String menusBrief = request.getParameter("menusBrief");
		String menusTypes1 = request.getParameter("menusTypes");
		int menusTypes = Integer.parseInt(menusTypes1);
		String imgpath = request.getParameter("imgpath");
		Menus menus = new Menus(menusName,new Types(menusTypes),menusBurden,menusBrief
				,menusPrice,menusPrice1,imgpath);
		ms.addMenu(menus); 
		return "servlet2?opType=foodMsg";
	}
	public String addType(HttpServletRequest request ,  String typesName){
		TypeService ts = new TypeServiceImpl();
		 ts.addTypes(typesName);
		return "servlet2?opType=foodTypeMsg";
	}
	

	public String deteleFood(HttpServletRequest request ,String menusId){
		MenusService ms = new MenusServiceImpl();
		int menusId1  = Integer.parseInt(menusId) ;
		ms.deleteMenu(menusId1);
		return "servlet2?opType=foodMsg";
		
	}
	
	public String deleteType(HttpServletRequest request ,String typesId){
		int typesId1 = Integer.parseInt(typesId);
		TypeService ts = new TypeServiceImpl();
		ts.deleteType(typesId1);
		return "servlet2?opType=foodTypeMsg";
	}
	
	public String toUpdateFood(HttpServletRequest request){
		TypeService ts = new TypeServiceImpl();
		MenusService ms = new MenusServiceImpl();
		List<Types> tList = ts.getTypes();			
		request.setAttribute("tList", tList);
		List<Menus> mList = ms.getMenusList();
		request.setAttribute("mList", mList);
		System.out.println("ok");
		return "updateFood.jsp";		
	}
	public String updateFood(HttpServletRequest request ){
		MenusService ms = new MenusServiceImpl();
		System.out.println(request.getParameter("menusId"));
		int menusId = Integer.parseInt(request.getParameter("menusId"));
		System.out.println(menusId);
		String menusName = request.getParameter("menusName");
		String menusBurden = request.getParameter("menusBurden");
		String menusPrice0 = request.getParameter("menusPrice");
		float menusPrice = Float.parseFloat(menusPrice0);
		String menusPrice11 = request.getParameter("menusPrice1");
		float menusPrice1 = Float.parseFloat(menusPrice11);
		String menusBrief = request.getParameter("menusBrief");
		String menusTypes1 = request.getParameter("menusTypes");
		int menusTypes = Integer.parseInt(menusTypes1);
		String imgpath = request.getParameter("imgpath");
		Menus menus = new Menus(menusId,menusName,new Types(menusTypes),menusBurden,menusBrief
				,menusPrice,menusPrice1,imgpath);
		ms.updateMenu(menus);
		 
		return "servlet2?opType=foodMsg";	
	}
	public String toUpdateType(HttpServletRequest request){
		
		return "updateTypes.jsp";		
	}
	public String updateTypes(HttpServletRequest request,String typesId){
		TypeService ts = new TypeServiceImpl();
		int typesId1 = Integer.parseInt(request.getParameter("typesId"));
		String foodType = request.getParameter("typename");
		Types types = new Types(typesId1,foodType);
		ts.updateType(types);
		return "servlet2?opType=foodTypeMsg";
	}
}
