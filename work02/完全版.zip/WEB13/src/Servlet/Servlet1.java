package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Admin;
import service.sfaceClass;



@WebServlet("/servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 public String result=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     login(request);
	     request.getRequestDispatcher(result).forward(request, response);
	   
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	 public void login(HttpServletRequest request)
	    {   
		    sfaceClass s = new sfaceClass();
	    	String adminName = request.getParameter("adminName");
	    	String adminPwd = request.getParameter("adminPwd");
	    	Admin ad = new Admin(adminName,adminPwd);
	    	Admin a = s.login(ad);
	    	if(a!=null)
	    	{
	    		result = "servlet2?opType=foodTypeMsg";
	    		request.getSession().setAttribute("Admin", a);
	    	}
	    	else
	    	{   
	    		result = "adminLogin.jsp";
	    		request.setAttribute("errormsg",  "�˺Ż��������");
	    	}
	    	
	    }
}
