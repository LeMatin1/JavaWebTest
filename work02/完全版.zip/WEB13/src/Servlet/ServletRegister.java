package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Users;
import server.RegisterService;
import serverImp.RegisterServiceImpl;






@WebServlet("/servletRegister")
public class ServletRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    RegisterService u=new RegisterServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String name=request.getParameter("name");
		System.out.println(name);
		String pwd=request.getParameter("pwd");
		String realname=request.getParameter("realname");
		String sex=request.getParameter("sex");
		String age=request.getParameter("age");
		int age1=Integer.parseInt(age);
		String card=request.getParameter("card");
		String address=request.getParameter("address");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		String emailcode=request.getParameter("emailcode");
		Users user=new Users(name,pwd,realname,sex, age1,card,address,phone ,email,emailcode);
		u.register(user);
		
		response.sendRedirect("regSuccessed.jsp");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
