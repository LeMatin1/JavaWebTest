package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Admin;
import service.AdminService;
import service.AdminServiceImpl;


@WebServlet("/adminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String  aName = request.getParameter("aName");
		String  aPassword = request.getParameter("aPassword");
		int  adminId = Integer.parseInt(request.getParameter("adminId")) ;
		AdminService as = new AdminServiceImpl();
		as.updateAdmin(new Admin(adminId,aName,aPassword) );
		request.getRequestDispatcher("Typejs.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
