package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Notice;
import service.sfaceClass;



@WebServlet("/Noticeservlet")
public class NoticeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public  String result = null;
	public sfaceClass s = new sfaceClass();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   
  	        String opType = request.getParameter("opType");
		    if(opType.equals("ToNoticeUpdate"))
		    {
		    	ToupdateNotice(request);
		    }
		    else if(opType.equals("NoticeDelete"))
		    {
		    	deleteNotice(request);
		    }
		    else if(opType.equals("NoticeList"))
		    {
		    	NoticeList(request);
		    }
		    else if(opType.equals("UpdateNotice"))
		    {
		    	updateNotice(request);
		    }
		    else if(opType.equals("new"))
		    {
		    	newNotice(request);
		    }
		    else if(opType.equals("ToNoticenew"))
		    {
		    	result = "new.jsp";
		    }
		    else if(opType.equals("init"))
		    {
		    	result = NoticeList7(request);
		    }
		    else if(opType.equals("allnotice"))
		    {
		    	allNoticeList(request);
		    }
		    request.getRequestDispatcher(result).forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	    
	    public void NoticeList(HttpServletRequest request)	    
	    {
	    	int  pagesize = 5;
	    	int currentpage = 1;
	    	int countpage = s.countpage1();
	    	String currentPageStr = request.getParameter("currentpage");
	    	if(currentPageStr!=null)
	    	{
	    		currentpage = Integer.parseInt(currentPageStr);
	    	}
	    	List<Notice> list = s.getlist(currentpage, pagesize);
	    	request.setAttribute("NoticeList", list);
	    	request.setAttribute("currentpage", currentpage);
	    	request.setAttribute("countpage", countpage);
	    	result = "Notice.jsp";
	    	
	}
	    
	    public void ToupdateNotice(HttpServletRequest request)
	    {   int a = 0;
	    	a = Integer.parseInt(request.getParameter("NoticeId"));
	    	Notice e = s.select(a);
	    	request.setAttribute("Notice", e);
	    	result = "UpdateNotice.jsp";
	    }
	    
	    public void updateNotice(HttpServletRequest request)

	    {  int a = 0;
	       a = Integer.parseInt(request.getParameter("NoticeId"));
	       String name = request.getParameter("name");
	       String context = request.getParameter("noticeContent");
	       String time = request.getParameter("noticeTimes");
	       Notice n = new Notice(a,name,context,time);
	       int a1 =s.update(n);
	       NoticeList(request);
	    }
	    
	    public void deleteNotice(HttpServletRequest request)
	    {
	    	int a = 0;
	    	a = Integer.parseInt(request.getParameter("NoticeId"));
	    	s.delete(a);
	    	NoticeList(request);
	    }
	    public void newNotice(HttpServletRequest request)

	    {
	    	String name = request.getParameter("name");
		    String context = request.getParameter("noticeContent");
		    String time = request.getParameter("noticeTimes");
		    Notice n = new Notice(name,context,time);
		    s.newone(n);
		    NoticeList(request);
	    }
	    public String NoticeList7(HttpServletRequest request)
	    {
	    	List<Notice> list = s.getlist7();
	    	request.getSession().setAttribute("noticeList",list);
	    	return "servlet2?opType=homepageMenus";
	    }
	    
	    public void allNoticeList(HttpServletRequest request)	    
	    {
	    	int  pagesize = 5;
	    	int currentpage = 1;
	    	int countpage = s.countpage1();
	    	String currentPageStr = request.getParameter("currentpage");
	    	if(currentPageStr!=null)
	    	{
	    		currentpage = Integer.parseInt(currentPageStr);
	    	}
	    	List<Notice> list = s.getlist(currentpage, pagesize);
	    	request.setAttribute("NoticeList", list);
	    	request.setAttribute("currentpage", currentpage);
	    	request.setAttribute("countpage", countpage);
	    	result = "allnotice.jsp";
	    	
	}
}
