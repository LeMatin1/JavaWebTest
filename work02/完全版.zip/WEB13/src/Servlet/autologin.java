package Servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Admin;
import server.NoticeServer;
import serverImp.NoticeServerImp;


@WebFilter("/autologin")
public class autologin implements Filter {


    public autologin() {
      
    }

	
	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest Request = (HttpServletRequest)request;
		HttpServletResponse Response = (HttpServletResponse)response;
		Cookie[] cookie = Request.getCookies();
		NoticeServer s = new NoticeServerImp();
		String adminName= null;
		String adminPwd = null;
		if(cookie!=null)
		{   
			for(Cookie co:cookie)
			{   
				if("adminName".equals(co.getName()))
				{
					adminName = co.getValue();
				}
				if("adminPwd".equals(co.getName()))
				{   
					adminPwd = co.getValue();
				}
				}
				
			}
		
		
		if(adminName!=null&&adminPwd!=null)
		{
			  Admin admin = s.login(new Admin(adminName,adminPwd));
				if(admin!=null)
				{   
					
			        Request.getSession().setAttribute("admin", admin);
				}
		}
		chain.doFilter(request, response);
	}


	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
